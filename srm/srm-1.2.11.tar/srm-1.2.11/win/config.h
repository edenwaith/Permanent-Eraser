#ifndef CONFIG__H
#define CONFIG__H

/* configuration for Win32 compilation */

#define PACKAGE "srm"
#define VERSION "1.2.11"

#define HAVE_STRING_H 1
#define _CRT_SECURE_NO_WARNINGS 1

#endif
