//
//  Permanent_EraserPref.h
//  Permanent Eraser
//
//  Created by carmstrong on 2/20/07.
//  Copyright (c) 2007 __MyCompanyName__. All rights reserved.
//

#import <PreferencePanes/PreferencePanes.h>


@interface Permanent_EraserPref : NSPreferencePane 
{

}

- (void) mainViewDidLoad;

@end
