//
//  Permanent_EraserPref.m
//  Permanent Eraser
//
//  Created by carmstrong on 2/20/07.
//  Copyright (c) 2007 __MyCompanyName__. All rights reserved.
//

#import "Permanent_EraserPref.h"


@implementation Permanent_EraserPref

- (void) mainViewDidLoad
{
}

@end
